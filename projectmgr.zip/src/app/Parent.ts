import { Project } from './Project';

export class Parent {
    Parent_Id : number;
    Parent_Task : string;
    Project_Id : number;
    Project : Project[];

}